from django.apps import AppConfig


class CouponsConfig(AppConfig):
    name = 'coupons'
